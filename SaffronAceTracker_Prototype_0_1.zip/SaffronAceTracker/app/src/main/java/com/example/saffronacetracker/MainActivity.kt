package com.example.saffronacetracker

import android.app.Activity
import android.os.Bundle
import android.graphics.Bitmap
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var history: TextView
    private val prefs by lazy { getSharedPreferences("tracker", MODE_PRIVATE) }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 28) }
        root.addView(TextView(this).apply { text = "Saffron Ace Tracker"; textSize = 24f })
        status = TextView(this).apply { text = "Sirf A♠ aur A♦ track honge."; textSize = 16f; setPadding(0, 20, 0, 20) }
        root.addView(status)
        root.addView(Button(this).apply { text = "Game screenshot select karke scan karein"; setOnClickListener { chooseImage() } })
        root.addView(Button(this).apply { text = "History refresh"; setOnClickListener { showHistory() } })
        history = TextView(this).apply { textSize = 14f; setPadding(0, 20, 0, 0) }
        root.addView(history)
        setContentView(ScrollView(this).apply { addView(root) })
        showHistory()
    }

    private fun chooseImage() {
        val intent = android.content.Intent(android.content.Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        startActivityForResult(intent, 42)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 42 || resultCode != Activity.RESULT_OK || data?.data == null) return
        val bitmap = try {
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                val source = android.graphics.ImageDecoder.createSource(contentResolver, data.data!!)
                android.graphics.ImageDecoder.decodeBitmap(source)
            } else {
                @Suppress("DEPRECATION")
                android.provider.MediaStore.Images.Media.getBitmap(contentResolver, data.data!!)
            }
        } catch (e: Exception) { status.text = "Image open nahi hui: ${e.message}"; return }
        scan(bitmap)
    }

    private fun scan(bitmap: Bitmap) {
        status.text = "Image scan ho rahi hai…"
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val card = CardDetector.detect(result.text)
                if (card == null) {
                    status.text = "A♠ ya A♦ detect nahi hua. OCR text: ${result.text}"
                } else {
                    val allText = result.text.lowercase()
                    val side = when {
                        "dragon" in allText && "tiger" !in allText -> "Dragon"
                        "tiger" in allText && "dragon" !in allText -> "Tiger"
                        else -> "Side confirm nahi"
                    }
                    val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                    val row = "$time | ${card.symbol} | $side"
                    val old = prefs.getString("rows", "") ?: ""
                    prefs.edit().putString("rows", (old + row + "\n").takeLast(20000)).apply()
                    status.text = "Record add hua: $row"
                    showHistory()
                }
            }
            .addOnFailureListener { status.text = "Scan error: ${it.message}" }
    }

    private fun showHistory() {
        val rows = prefs.getString("rows", "") ?: ""
        history.text = if (rows.isBlank()) "Abhi koi record nahi." else "Recent records:\n" + rows.lines().takeLast(20).reversed().joinToString("\n")
    }
}

data class TrackedCard(val symbol: String)

object CardDetector {
    fun detect(text: String): TrackedCard? {
        val normalized = text.uppercase().replace("ACE", "A")
        return when {
            Regex("(?<![A-Z0-9])A\\s*♠").containsMatchIn(normalized) || Regex("A\\s+SPADE").containsMatchIn(normalized) -> TrackedCard("A♠")
            Regex("(?<![A-Z0-9])A\\s*♦").containsMatchIn(normalized) || Regex("A\\s+DIAMOND").containsMatchIn(normalized) -> TrackedCard("A♦")
            else -> null
        }
    }
}
