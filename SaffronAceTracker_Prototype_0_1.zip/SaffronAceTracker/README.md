# Saffron Ace Tracker — prototype 0.1

First Android Studio source prototype. It lets the user select a screenshot and runs on-device ML Kit OCR. If OCR clearly recognizes A♠ or A♦, it stores a timestamp and a preliminary side label in local app history.

## Important: current limitations
- This is **not yet automatic live screen tracking**; it scans user-selected screenshots only.
- Card suits shown as graphics may not be recognized by OCR. A visual template/classifier must be calibrated using multiple genuine result screenshots.
- Side detection is preliminary and may be ambiguous because both Dragon and Tiger labels can appear on the same page.
- Round ID extraction and duplicate-round prevention are not implemented yet.
- No login credentials or OTP are needed.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then run on an Android phone. A Gradle wrapper is not included.

## Next step
Add Android MediaProjection with explicit user consent, crop the two result-card regions, and implement visual card recognition plus round-ID extraction. Keep processing local and store only detected card, side, round ID and timestamp. Only use permitted screen capture; do not bypass site access controls.
